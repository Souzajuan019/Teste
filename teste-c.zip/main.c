#include <stdio.h>
#include <math.h> 
int main ()
{
int a,b,c;
 printf("digite um valor");
 scanf("%d",&a);
 printf("digite mais um valor");
 scanf("%d",&b);

c=a+b
    
    return,0
}